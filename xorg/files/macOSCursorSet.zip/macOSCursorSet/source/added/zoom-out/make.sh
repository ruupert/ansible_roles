#!/bin/sh
xcursorgen zoom-out.cursor zoom-out
