#!/bin/sh
xcursorgen circle.cursor circle
