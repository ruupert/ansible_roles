#!/bin/sh
xcursorgen dnd-none.cursor dnd-none
