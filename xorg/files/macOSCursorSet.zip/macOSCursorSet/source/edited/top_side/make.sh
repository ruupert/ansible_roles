#!/bin/sh
xcursorgen top_side.in top_side
