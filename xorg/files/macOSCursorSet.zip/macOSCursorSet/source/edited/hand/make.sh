#!/bin/sh
xcursorgen hand1.cursor hand1
xcursorgen hand1.cursor hand2

cp    hand1				9d800788f1b08800ae810202380a0822
cp    hand2				e29285e634086352946a0e7090d73106
cp    hand1				hand
