#!/bin/sh
xcursorgen dnd-copy.cursor dnd-copy
