#!/bin/sh
xcursorgen right_ptr.in right_ptr

cp    right_ptr			draft_large
cp    right_ptr			draft_small

