#!/bin/sh
xcursorgen fleur.cursor fleur
