#!/bin/sh
xcursorgen left_ptr.in left_ptr

cp    left_ptr			arrow
cp    left_ptr			top_left_arrow
