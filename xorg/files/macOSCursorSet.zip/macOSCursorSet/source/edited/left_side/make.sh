#!/bin/sh
xcursorgen left_side.in left_side
